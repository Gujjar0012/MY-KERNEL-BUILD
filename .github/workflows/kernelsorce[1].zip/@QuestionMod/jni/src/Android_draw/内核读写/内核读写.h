#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "过缺页.h"
#include "morishima_fonts.hpp"
#include <regex.h>
long int 自身结构体;
#define FileCount 4
const char *files[FileCount] = { "春圣zzs" };
uintptr_t 基址头;
pid_t 进程=0;

class c_driver{
private:
int has_upper = 0;
int has_lower = 0;
int has_symbol = 0;
int has_digit = 0;
int fd;
pid_t 进程;

typedef struct _COPY_MEMORY{
pid_t 进程;
uintptr_t 地址;
void *buffer;
size_t size;
} COPY_MEMORY, *PCOPY_MEMORY;

typedef struct _MODULE_BASE{
pid_t 进程;
char *name;
uintptr_t 基址头;
} MODULE_BASE, *PMODULE_BASE;

	enum OPERATIONS {
		OP_INIT_KEY = 0x800,
		OP_READ_MEM = 0x801,
		OP_WRITE_MEM = 0x802,
		OP_MODULE_BASE = 0x803,
	};
	
	int symbol_file(const char *filename) {
		//判断文件名是否含小写并且不含大写不含数字不含符号
		int length = strlen(filename);
		for (int i = 0; i < length; i++) {
			if (islower(filename[i])) {
				has_lower = 1;
			} else if (isupper(filename[i])) {
				has_upper = 1;
			} else if (ispunct(filename[i])) {
				has_symbol = 1;
			} else if (isdigit(filename[i])) {
				has_digit = 1;
			}
		}
		return has_lower && !has_upper && !has_symbol && !has_digit;
	}
	
	char *driver_path() {
	// 打开目录
		const char *dev_path = "/dev";
		DIR *dir = opendir(dev_path);
		if (dir == NULL){
			printf("无法打开/dev目录\n");
			return NULL;
		}

		char *files[] = { "wanbai", "CheckMe", "Ckanri", "lanran","video188"};
		struct dirent *entry;
		char *file_path = NULL;
		while ((entry = readdir(dir)) != NULL) {
			// 跳过当前目录和上级目录
			if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
				continue;
			}

			size_t path_length = strlen(dev_path) + strlen(entry->d_name) + 2;
			file_path = (char *)malloc(path_length);
			snprintf(file_path, path_length, "%s/%s", dev_path, entry->d_name);
			for (int i = 0; i < 5; i++) {
				if (strcmp(entry->d_name, files[i]) == 0) {
					printf("驱动文件：%s\n", file_path);
					closedir(dir);
					return file_path;
				}
			}

			// 获取文件stat结构
			struct stat file_info;
			if (stat(file_path, &file_info) < 0) {
				free(file_path);
				file_path = NULL;
				continue;
			}

			// 跳过gpio接口
			if (strstr(entry->d_name, "gpiochip") != NULL) {
				free(file_path);
				file_path = NULL;
				continue;
			}

			// 检查是否为驱动文件
			if ((S_ISCHR(file_info.st_mode) || S_ISBLK(file_info.st_mode))
				&& strchr(entry->d_name, '_') == NULL && strchr(entry->d_name, '-') == NULL && strchr(entry->d_name, ':') == NULL) {
				// 过滤标准输入输出
				if (strcmp(entry->d_name, "stdin") == 0 || strcmp(entry->d_name, "stdout") == 0
					|| strcmp(entry->d_name, "stderr") == 0) {
					free(file_path);
					file_path = NULL;
					continue;
				}
				
				size_t file_name_length = strlen(entry->d_name);
				time_t current_time;
				time(&current_time);
				int current_year = localtime(&current_time)->tm_year + 1900;
				int file_year = localtime(&file_info.st_ctime)->tm_year + 1900;
				//跳过1980年前的文件
				if (file_year <= 1980) {
					free(file_path);
					file_path = NULL;
					continue;
				}
				
				time_t atime = file_info.st_atime;
				time_t ctime = file_info.st_ctime;
				// 检查最近访问时间和修改时间是否一致并且文件名是否是symbol文件
				if ((atime == ctime)/* && symbol_file(entry->d_name)*/) {
					//检查mode权限类型是否为S_IFREG(普通文件)和大小还有gid和uid是否为0(root)并且文件名称长度在7位或7位以下
					if ((file_info.st_mode & S_IFMT) == 8192 && file_info.st_size == 0
						&& file_info.st_gid == 0 && file_info.st_uid == 0 && file_name_length <= 9) {
						printf("驱动文件：%s\n", file_path);
						closedir(dir);
						return file_path;
					}
				}
			}
			free(file_path);
			file_path = NULL;
		}
		closedir(dir);
		return NULL;
	}

    char *find_driver_path() {
    // 优先检查 /proc 目录
    DIR *dr = opendir("/proc");
    if (!dr) {
      perror("节点打开失败/proc");
      return NULL;
    }

    struct dirent *de;
    char *driver_path = NULL;
    while ((de = readdir(dr)) != NULL) {
      if (strlen(de->d_name) != 6 || !isdigit(de->d_name[0])) continue;

      char tmp_path[128];
      snprintf(tmp_path, sizeof(tmp_path), "/proc/%s", de->d_name);
      struct stat sb;
      if (stat(tmp_path, &sb) == 0 && S_ISREG(sb.st_mode)) {
        driver_path = strdup(tmp_path);
        break;
      }
    }

    // 如果在 /proc 中没有找到路径，则返回 NULL
    if (!driver_path) {
        printf("没有在 /proc 目录中找到驱动\n");
    }

    return driver_path;  // 确保返回找到的路径
}

public:
    c_driver() {  // 将构造函数设置为public
        char *device_name = driver_path();
        if (!device_name) {
            device_name = find_driver_path();
        }

        if (!device_name) {
            fprintf(stderr, "[-] 找不到驱动\n");
            exit(EXIT_FAILURE);
        }

        fd = open(device_name, O_RDWR);
        free(device_name);

        if (fd == -1) {
            perror("[-] 打开失败");
            exit(EXIT_FAILURE);
        }
    }

    ~c_driver()
    {
        // wont be called
        if (fd > 0)
            close(fd);
    }
void 初始化(pid_t 进程){
this->进程 = 进程;
}

bool 读取(uintptr_t 地址, void *buffer, size_t size){
if (地址 <= 0x10000000 || 地址 % 4 != 0 || 地址 >= 0x10000000000){
return 0;
}
COPY_MEMORY cm;
cm.进程 = this->进程;
cm.地址 = 地址;
cm.buffer = buffer;
cm.size = size;
if (ioctl(fd, OP_READ_MEM, &cm) != 0){
return false;
}
return true;
}

bool 写入(uintptr_t 地址, void *buffer, size_t size){
COPY_MEMORY cm;
cm.进程 = this->进程;
cm.地址 = 地址;
cm.buffer = buffer;
cm.size = size;
if (ioctl(fd, OP_WRITE_MEM, &cm) != 0){
return false;
}
return true;
}

template < typename T > T 读取(uintptr_t 地址){
T res;
if (this->读取(地址, &res, sizeof(T)))
return res;
return{
};
}

template < typename T > bool 写入(uintptr_t 地址, T value){
return this->写入(地址, &value, sizeof(T));
}

bool GetName(char *Name, long int address, int id)
{
    long int ClassNameadd = 0;
    long int ClassNameaddr = 0;
    
    // 尝试读取ClassNameadd
    if (!this->读取(address + (id / 0x4000) * 0x8, &ClassNameadd, sizeof(uintptr_t))) {
        return false; // 如果读取失败，返回false
    }
    
    // 尝试读取ClassNameaddr
    if (!this->读取(ClassNameadd + (id % 0x4000) * 0x8, &ClassNameaddr, sizeof(uintptr_t))) {
        return false; // 如果读取失败，返回false
    }
    
    // 最后尝试读取类名到Name
    if (!this->读取(ClassNameaddr + 0xC, Name, 32)) {
        return false; // 如果读取失败，返回false
    }
    
    return true; // 所有读取操作成功完成
}

long 读取指针(long 地址){
if (地址 <= 0x10000000 || 地址 % 4 != 0 || 地址 >= 0x10000000000){
return 0;
}
long res;
if (this->读取(地址,&res,sizeof(uintptr_t))){
return res;
}
return {};
}

float 读取浮点数(long 地址){
if (地址 < 0xFFFFFF){
return 0;
}
float var;
if (this->读取(地址&0xFFFFFFFFFF,&var,sizeof(var))){
return var;
}
return {};
}

int 读取整数(long 地址){
if (地址 <= 0x10000000 || 地址 % 4 != 0 || 地址 >= 0x10000000000){
return 0;
}
int 数据;
if (this->读取(地址&0xFFFFFFFFFF,&数据,sizeof(数据))){
return 数据;
}
return {};
}

// 写入F类内存
void 写入F类内存(unsigned long 地址, float 数据){
this->写入(地址, &数据, 4);
}
// 写入D类内存
void 写入D类内存(unsigned long 地址, int 数据){
this->写入(地址, &数据, 4);
}

pid_t 获取进程(char *name){
FILE *fp;
pid_t 进程;
char cmd[0x100] = "pidof ";
strcat(cmd, name);
fp = popen(cmd, "r");
fscanf(fp, "%d", &进程);
pclose(fp);
return 进程;
}

uintptr_t 获取基址头(char *name){
MODULE_BASE mb;
char buf[0x100];
strcpy(buf, name);
mb.进程 = this->进程;
mb.name = buf;
if (ioctl(fd, OP_MODULE_BASE, &mb) != 0){
return 0;
}
return mb.基址头;
}

};//结束

static c_driver *驱动 = new c_driver();