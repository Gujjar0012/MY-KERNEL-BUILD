#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <functional>
#include <chrono>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <linux/input.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <random>  

#include "凯撒字体.h"
#include "draw.h"
#include "ANativeWindowCreator.h"
#include "内核读写/数组解密.h"
#include "内存图片/Zeus图标.h"
#include "include.h"
#include "封装绘图.h"
#include "结构体.h"
#include "绘图.h"

#include <iostream>
 #include <sstream> 
 #include <iomanip>

std::vector<std::thread> threadPool; 



std::string longIntToHexString(long int number) {
    std::stringstream ss;
    ss << std::hex << std::setw(8) << std::setfill('0') << number;
    return ss.str();
}


bool 已挂载 = false;
bool kang;
std::mutex mtx; 
int style_ida = 0;
int style_idx = 0;
int style_ido = 0;
float 狗子自瞄;
static bool 菜单 = true;
static bool IsBall = true;
bool isSetSize = false;
int 数量;
bool screenshotScheduled = false;
double screenshotStartTime = 0.0;
double tooltipStartTime = 0.0;
bool showOverlay = false;
void takeScreenshot() {
    std::random_device rd;
    std::uniform_int_distribution<int> dist(100000, 999999);
    int random_number = dist(rd);
    std::string file_name = "game_" + std::to_string(random_number) + ".png";
    std::thread([file_name]() {
        std::string command = "screencap -p /sdcard/" + file_name;
        system(command.c_str());
    }).detach();
}

void ImGuiMenustyle();
void NumIoLoad(const char *name);

ANativeWindow *native_window;
android::ANativeWindowCreator::DisplayInfo displayInfo{0};
int FPS;
int 帧数 = 60;
timer FPS限制;
float FPF显示;
Screen full_screen;
int Orientation = 0;
int screen_x = 0, screen_y = 0;
int init_screen_x = 0, init_screen_y = 0;
bool g_Initialized = false;

string exec(string command) {
char buffer[128];
string result = "";

FILE* pipe = popen(command.c_str(), "r");
if (!pipe) {
return "popen failed!";
}

while (!feof(pipe)) {

if (fgets(buffer, 128, pipe) != nullptr){
result += buffer;
}
}
pclose(pipe);
return result;
}

int init_Vulkan(int _screen_x, int _screen_y, bool log) {
    InitVulkan();
    SetupVulkan();
    ::native_window = android::ANativeWindowCreator::Create("AImGui", _screen_x, _screen_y, false);
    SetupVulkanWindow(::native_window, (int) _screen_x, (int) _screen_y);
    return 1;
}

void ImGui_init() {
    if (g_Initialized) {
        return;
    }
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = NULL;
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
       io.Fonts->AddFontFromMemoryTTF((void *)Font_data, Font_size, 25.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
    ImGui::GetStyle().ScaleAllSizes(3.0f);


    UploadFonts();  


    ImGuiMenustyle(); 
    ColorInitialization();
    颜色初始化();
    NumIoLoad("Question Mod");

    FloatBall = ImAgeHeadFile_Vk(icon, sizeof(icon));
    加载图片();

    ::g_Initialized = true;
}

void drawEnd() {
    ImGui::Render();    
    
    FrameRender(ImGui::GetDrawData());
    FramePresent();
}

void shutdown() {
    if (!g_Initialized) {
        return;
    }
    DeviceWait();
    ImGui_ImplVulkan_Shutdown();
    
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();    
    
    CleanupVulkanWindow();
    CleanupVulkan();
    android::ANativeWindowCreator::Destroy(native_window);
    ::g_Initialized = false;
}

void screen_config(){
std::string window_size = exec("wm size");
sscanf(window_size.c_str(),"Physical size: %dx%d",&screen_x, &screen_y);
full_screen.ScreenX = screen_x;
full_screen.ScreenY = screen_y;
std::thread *orithread = new std::thread([&] {
while(true){
Orientation = atoi(exec("dumpsys display | grep 'mCurrentOrientation' | cut -d'=' -f2").c_str());

if(Orientation == 0 || Orientation == 2){
screen_x = full_screen.ScreenX;
screen_y = full_screen.ScreenY;
}
if(Orientation == 1 || Orientation == 3){
screen_x = full_screen.ScreenY;
screen_y = full_screen.ScreenX;
}
std::this_thread::sleep_for(0.5s);
}
});
orithread->detach();
}


void NumIoSave(const char *name){
if (numSave == nullptr) {
string SaveFile = "/data/local/tmp";
SaveFile += "/";
SaveFile += name;
numSave = fopen(SaveFile.c_str(), "wb+");
}

fseek(numSave, 0, SEEK_SET);
fwrite(&Config.自动瞄准.优先方式, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.瞄准部位, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.锁定强度,sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.瞄准速度, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.触摸范围, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.子弹速度,sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.压枪参数, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.预判参数, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.子弹下坠预判, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.触摸位置Y, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.触摸位置X,sizeof(float), 1, numSave);
fwrite(&Config.预警绘制.雷达X轴, sizeof(float), 1, numSave);
fwrite(&Config.预警绘制.雷达Y轴, sizeof(float), 1, numSave);
fwrite(&Config.预警绘制.雷达大小, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.范围粗细, sizeof(float), 1, numSave);
fwrite(&Config.自动瞄准.自瞄距离, sizeof(float), 1, numSave);
fwrite(&Config.预警绘制. 菜单X轴, sizeof(float), 1, numSave);
fwrite(&Config.预警绘制. 菜单Y轴, sizeof(float), 1, numSave);
fwrite(&Config.人物绘制.绘制方框, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.绘制射线, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.绘制骨骼, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.绘制信息, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.绘制类名, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.盒子绘制, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.绘制距离, sizeof(bool), 1, numSave);
fwrite(&Config.预警绘制.绘制雷达, sizeof(bool), 1, numSave);
fwrite(&Config.人物绘制.忽略人机, sizeof(bool), 1, numSave);
fwrite(&Config.预警绘制.背敌预警, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.头, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.手持武器, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.载具绘制, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.地铁盒子, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.箱子绘制, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.狗子骨骼, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.狗子, sizeof(bool), 1, numSave);
fwrite(&Config.其他绘制.手雷绘制, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.自瞄开关, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.单发压枪, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.忽略附近有人, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.动态范围, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.忽略倒地, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.忽略人机, sizeof(bool), 1, numSave);
fwrite(&Config.自动瞄准.忽略远处狗子, sizeof(bool), 1, numSave);
fread(&Config.预警绘制.雷达样式, sizeof(bool), 1, numSave);
fflush(numSave);
fsync(fileno(numSave));
}

void NumIoLoad(const char *name){
if (numSave == nullptr) {
string SaveFile = "/data/local/tmp";
SaveFile += "/";
SaveFile += name;
numSave = fopen(SaveFile.c_str(), "rb+");
}
if (numSave != nullptr) {
fseek(numSave, 0, SEEK_SET);
fread(&Config.自动瞄准.优先方式, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.瞄准部位, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.锁定强度,sizeof(float), 1, numSave);
fread(&Config.自动瞄准.瞄准速度, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.触摸范围, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.子弹速度,sizeof(float), 1, numSave);
fread(&Config.自动瞄准.压枪参数, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.预判参数, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.子弹下坠预判, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.触摸位置Y, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.触摸位置X,sizeof(float), 1, numSave);
fread(&Config.预警绘制.雷达X轴, sizeof(float), 1, numSave);
fread(&Config.预警绘制.雷达Y轴, sizeof(float), 1, numSave);
fread(&Config.预警绘制.雷达大小, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.范围粗细, sizeof(float), 1, numSave);
fread(&Config.自动瞄准.自瞄距离, sizeof(float), 1, numSave);
fread(&Config.预警绘制. 菜单X轴, sizeof(float), 1, numSave);
fread(&Config.预警绘制. 菜单Y轴, sizeof(float), 1, numSave);
fread(&Config.人物绘制.绘制方框, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.绘制射线, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.绘制骨骼, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.绘制信息, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.绘制类名, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.盒子绘制, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.绘制距离, sizeof(bool), 1, numSave);
fread(&Config.预警绘制.绘制雷达, sizeof(bool), 1, numSave);
fread(&Config.人物绘制.忽略人机, sizeof(bool), 1, numSave);
fread(&Config.预警绘制.背敌预警, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.头, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.地铁盒子, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.箱子绘制, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.手持武器, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.载具绘制, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.狗子骨骼, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.狗子, sizeof(bool), 1, numSave);
fread(&Config.其他绘制.手雷绘制, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.自瞄开关, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.单发压枪, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.忽略附近有人, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.动态范围, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.忽略倒地, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.忽略人机, sizeof(bool), 1, numSave);
fread(&Config.自动瞄准.忽略远处狗子, sizeof(bool), 1, numSave);
fread(&Config.预警绘制.雷达样式, sizeof(bool), 1, numSave);
} else {
        Config.预警绘制.雷达样式 = 0.0f;
        Config.自动瞄准.优先方式 = 0.0f;
        Config.自动瞄准.瞄准部位 = 0.0f;
        Config.预警绘制.雷达X轴 = 300.0f;
        Config.预警绘制.雷达Y轴 = 400.0f;
        Config.自动瞄准.自瞄范围 = 175.0f;
        Config.自动瞄准.触摸位置Y = 1500.0f;
        Config.自动瞄准.触摸位置X = 650.0f;
        Config.自动瞄准.触摸范围 = 300.0f;
        Config.自动瞄准.锁定强度 = 0.0f;
        Config.自动瞄准.瞄准速度 = 50.0f;
        Config.自动瞄准.子弹速度 = 550.0f;
        Config.自动瞄准.压枪参数 = 3.0f;
        Config.自动瞄准.子弹下坠预判 = 0.0f;
        Config.自动瞄准.预判参数 = 1.5f;
        Config.预警绘制.缩放 = 200.0f;
        Config.预警绘制.雷达大小 = 150.0f;
        Config.自动瞄准.范围粗细 = 1.5f;
        Config.自动瞄准.自瞄距离 = 300.0f;
        Config.预警绘制. 菜单X轴 = 1.8f;
        Config.预警绘制. 菜单Y轴 = 2.8f;
        
        
        
        


        
}
}

void ImGuiMenustyle() {
        Config.预警绘制.雷达样式 = 0.0f;
        Config.自动瞄准.优先方式 = 0.0f;
        Config.自动瞄准.瞄准部位 = 0.0f;
        Config.预警绘制.雷达X轴 = 300.0f;
        Config.预警绘制.雷达Y轴 = 400.0f;
        Config.自动瞄准.自瞄范围 = 175.0f;
        Config.自动瞄准.触摸位置Y = 1500.0f;
        Config.自动瞄准.触摸位置X = 650.0f;
        Config.自动瞄准.触摸范围 = 300.0f;
        Config.自动瞄准.锁定强度 = 0.0f;
        Config.自动瞄准.瞄准速度 = 50.0f;
        Config.自动瞄准.子弹速度 = 550.0f;
        Config.自动瞄准.压枪参数 = 3.0f;
        Config.自动瞄准.子弹下坠预判 = 0.0;
        Config.自动瞄准.预判参数 = 1.5f;
        Config.预警绘制.缩放 = 200.0f;
        Config.预警绘制.雷达大小 = 150.0f;
        Config.自动瞄准.范围粗细 = 1.5f;
        Config.自动瞄准.自瞄距离 = 300.0f;
        Config.预警绘制. 菜单X轴 = 1.8f;
        Config.预警绘制. 菜单Y轴 = 2.8f;
        FPS = 144;
}


struct AimStruct {
Vector3A ObjAim;
Vector3A MyObjAim;
Vector3A AimMovement;
float ScreenDistance = 0;
float WodDistance = 0; 
char Name[32];
}Aim[100];


bool IsAimLongAim = false;
char AimName[32];


int findminat()
{
  float min = Config.自动瞄准.自瞄范围;
  int minAt = 999;
  float DistanceMin = 300;
  for (int i = 0; i < MaxPlayerCount; i++)
  {
    switch ((int)Config.自动瞄准.优先方式)
        {
            case 0:
                if (IsAimLongAim) {
					if (strcmp(Aim[i].Name, AimName) == 0)
    				{           	
        				minAt = i;
    				}
				} else {
    				if (Aim[i].ScreenDistance < min)
    				{
						if (Config.自动瞄准.持续锁定) {
							strcpy(AimName, Aim[i].Name);
						}
        				min = Aim[i].ScreenDistance;
        				minAt = i;
    				}
				}
			break;
			case 1:
                if (IsAimLongAim) {
					if (strcmp(Aim[i].Name, AimName) == 0)
    				{           	
        				minAt = i;
    				}
				} else {
    				if (Aim[i].WodDistance < DistanceMin)
    				{
						if (Config.自动瞄准.持续锁定) {
							strcpy(AimName, Aim[i].Name);
						}
        				DistanceMin = Aim[i].WodDistance;
        				minAt = i;
					}
    			}
        	break;
		}    
  }
  if (minAt == 999)
  {
    Gmin = -1;
    return -1;
  }
  Gmin = minAt;   
    Aim[minAt].WodDistance;
	if (Config.自动瞄准.持续锁定) {
		IsAimLongAim = true;
  }
  Gmin = minAt;
  WorldDistance = Aim[minAt].WodDistance;
  return minAt;
}

float GetPitch(float Fov)
{
if (Fov > 75 && Fov <= 130)          
    {
        return 0.8f * Config.自动瞄准.压枪参数;
    }
    else if (Fov == 70 || Fov == 75)    
    {     
        return 2.5f * Config.自动瞄准.压枪参数;       
    }
    else if (Fov == 55 || Fov == 60)    
    {
        return 2.5f * Config.自动瞄准.压枪参数;
    }   
    else if ((int)Fov == 44)    
    {
        return 5.1f * Config.自动瞄准.压枪参数;
    }
    else if ((int)Fov == 26)    
    {
        return 7.1f * Config.自动瞄准.压枪参数;
    }
    else if ((int)Fov == 20)    
    {
        return 8.4f * Config.自动瞄准.压枪参数;
    }
    else if ((int)Fov == 13)    
    {       
        return 13.9f * Config.自动瞄准.压枪参数;
    }
	return 2.5f * Config.自动瞄准.压枪参数;   
}
Vector2A vpvp;
float fwjl = Config.自动瞄准.自瞄范围;
float xzb = Config.自动瞄准.触摸位置X;
float yzb = Config.自动瞄准.触摸位置Y;

void AimBotAuto()
{

    std::lock_guard<std::mutex> lock(mtx);

    bool isDown = false;
    
    double leenx = 0.0f;
    
    double leeny = 0.0f;
    
    double de = 1.5f;
    

    double tx = Config.自动瞄准.触摸位置X, ty = Config.自动瞄准.触摸位置Y;
    

    float SpeedMin = 2.0f;
    

    double w = 0.0f, h = 0.0f, cmp = 0.0f;
    

    double ScreenX, ScreenY;

    if (screen_x < screen_y)
    {
        ScreenX = screen_x;
        ScreenY = screen_y;
    }
    else
    {
        ScreenX = screen_y;
        ScreenY = screen_x;
    }

    

    double ScrXH = ScreenX / 2.0f;
    

    double ScrYH = ScreenY / 2.0f;
    

    static float TargetX = 0;
    static float TargetY = 0;
    

    Vector3A obj;

    float NowCoor[3];

    TouchScreenHandle();

    while (1)
    {
        std::srand(static_cast<unsigned int>(std::time(nullptr)));

        
        float randomNumber = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX / 20.0) - 10.0;

        yzb = Config.自动瞄准.触摸位置Y + randomNumber;

        randomNumber = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX / 20.0) - 10.0;

        xzb = Config.自动瞄准.触摸位置X + randomNumber;

        usleep(1000000 / 120);

        ImGuiIO &iooi = ImGui::GetIO();

        if (Config.自动瞄准.触摸位置 && iooi.MouseDown[0] && iooi.MousePos.x <= Config.自动瞄准.触摸位置Y + Config.自动瞄准.触摸范围 && iooi.MousePos.y <= screen_y - Config.自动瞄准.触摸位置X + Config.自动瞄准.触摸范围 && iooi.MousePos.x >= Config.自动瞄准.触摸位置Y - Config.自动瞄准.触摸范围 && iooi.MousePos.y >= screen_y - Config.自动瞄准.触摸位置X - Config.自动瞄准.触摸范围)
        {
            usleep(30000);
            if (Config.自动瞄准.触摸位置 && iooi.MouseDown[0] && iooi.MousePos.x <= Config.自动瞄准.触摸位置Y + Config.自动瞄准.触摸范围 && iooi.MousePos.y <= screen_y - Config.自动瞄准.触摸位置X + Config.自动瞄准.触摸范围 && iooi.MousePos.x >= Config.自动瞄准.触摸位置Y - Config.自动瞄准.触摸范围 && iooi.MousePos.y >= screen_y - Config.自动瞄准.触摸位置X - Config.自动瞄准.触摸范围)
            {
                while (Config.自动瞄准.触摸位置 && iooi.MouseDown[0] && iooi.MousePos.x <= Config.自动瞄准.触摸位置Y + Config.自动瞄准.触摸范围 && iooi.MousePos.y <= screen_y - Config.自动瞄准.触摸位置X + Config.自动瞄准.触摸范围 && iooi.MousePos.x >= Config.自动瞄准.触摸位置Y - Config.自动瞄准.触摸范围 && iooi.MousePos.y >= screen_y - Config.自动瞄准.触摸位置X - Config.自动瞄准.触摸范围)
                {
                    Config.自动瞄准.触摸位置Y = iooi.MousePos.x;
                    Config.自动瞄准.触摸位置X = screen_y - iooi.MousePos.y;
                    TouchingColor = ImColor(0, 220, 0, 150);
                    usleep(500);
                }
                TouchingColor = ImColor(255, 0, 0, 150);
            }
        }
		

        if (!Config.自动瞄准.自瞄开关)
        {

            if (isDown == true)
            {
                usleep(1000);
                tx = xzb, ty = yzb;
                
                Touch_Up(6);
                
                isDown = false;
            }
            usleep(Config.自动瞄准.锁定强度 * 1000);
            usleep(randomNumber + 20);
            continue;
        }

        findminat();
        

        if (Gmin == -1)
        {

            if (isDown == true)
            {

                tx = xzb, ty = yzb;
                
                Touch_Up(6);
                
                isDown = false;
            }

            continue;
        }

        float fov = 驱动->读取浮点数(驱动->读取指针(驱动->读取指针(基址头 + 0x49e0) + 0x4e0) + 0x4f0);

        float ToReticleDistance = Aim[Gmin].ScreenDistance;
        float FlyTime = Aim[Gmin].WodDistance / Config.自动瞄准.子弹速度;
        
        float DropM = 500.0f * Config.自动瞄准.子弹下坠预判* FlyTime;
		



  


        int 开火判断 = 驱动->读取整数(自身结构体 + 0x1708);
        int 开镜判断 = 驱动->读取整数(自身结构体 + 0x1071);

        NowCoor[0] = Aim[Gmin].ObjAim.X;
        NowCoor[1] = Aim[Gmin].ObjAim.Y;
        NowCoor[2] = Aim[Gmin].ObjAim.Z;
        obj.X = NowCoor[0] + (Aim[Gmin].AimMovement.X * FlyTime * Config.自动瞄准.预判参数);
        obj.Y = NowCoor[1] + (Aim[Gmin].AimMovement.Y * FlyTime * Config.自动瞄准.预判参数);
        obj.Z = NowCoor[2] + (Aim[Gmin].AimMovement.Z * FlyTime * Config.自动瞄准.预判参数) + DropM;


        if (开火判断)
            obj.Z -= Aim[Gmin].WodDistance * Config.自动瞄准.压枪参数 * GetWeaponId(MyWeapon);
        if (Config.自动瞄准.单发压枪)
        {
            if (开镜判断 == 256)
            {
                obj.Z -= Aim[Gmin].WodDistance * Config.自动瞄准.压枪参数 * GetWeaponId(MyWeapon);
            }
        }
        float cameras = matrix[3] * obj.X + matrix[7] * obj.Y + matrix[11] * obj.Z + matrix[15];

        vpvp = WorldToScreen(obj, matrix, cameras);
        float AimDs = sqrt(pow(px - vpvp.X, 2) + pow(py - vpvp.Y, 2));
        if (Config.自动瞄准.动态范围 && 开镜判断 == 256 || 开火判断 == 1)
        {

            fwjl = AimDs;
        }
        else
        {
            fwjl = Config.自动瞄准.自瞄范围;
        }
        zm_y = vpvp.X;
        zm_x = ScreenX - vpvp.Y;

        float Aimspeace = Config.自动瞄准.瞄准速度;

        if (zm_x <= 0 || zm_x >= ScreenX || zm_y <= 0 || zm_y >= ScreenY)
        {

            if (isDown == true)
            {
                usleep(1000);
                tx = xzb, ty = yzb;
                
                Touch_Up(6);
                
                isDown = false;
            }
            usleep(Config.自动瞄准.锁定强度 * 1000);
            usleep(randomNumber + 20);
            continue;
        }

        if (ToReticleDistance <= Config.自动瞄准.自瞄范围) {      
        /*   
            switch ((int)Config.自动瞄准.触发方式)
            {
                case 0:
                    if (开火判断 != 1)
                    {
                        if (isDown == true)
                        {
                        
                            tx = xzb, ty = yzb;
                            
                            Touch_Up(6);
                            isDown = false;
                        }                      
                        usleep(Config.自动瞄准.锁定强度 * 1000);
                        continue;
                    }
                break;
                case 1:
                    if (开镜判断 != 256)
                    {
                        if (isDown == true)
                        {
                            tx = xzb, ty = yzb;
                            
                            Touch_Up(6);
                            isDown = false;
                        }
                        usleep(Config.自动瞄准.锁定强度 * 1000);
                        continue;
                    }
                break;
                case 2:
                    if (开火判断 != 1 && 开镜判断 != 256)
                    {
                        if (isDown == true)
                        {
                            tx = xzb, ty = yzb;
                            
                            Touch_Up(6);
                            isDown = false;
                        }
                        usleep(Config.自动瞄准.锁定强度 * 1000);
                        continue;
                    }
                break;
            }         
             */
            if (Config.自动瞄准.触发方式 == 自瞄触发方式::开火) {
if (开火判断 != 1) {
IsAimLongAim = false;
if (isDown == true)
{
    usleep(1000);
    usleep(randomNumber + 20);
    tx = xzb, ty = yzb;
    
    Touch_Up(6);
    isDown = false;
}
usleep(Config.自动瞄准.锁定强度 * 1000);
continue;
}
} else if (Config.自动瞄准.触发方式 == 自瞄触发方式::开镜) {
if (开镜判断 != 1) {
IsAimLongAim = false;
{
    usleep(1000);
    usleep(randomNumber + 20);
    tx = xzb, ty = yzb;
    
    Touch_Up(6);
    isDown = false;
}
usleep(Config.自动瞄准.锁定强度 * 1000);
continue;
}
} else if (Config.自动瞄准.触发方式 == 自瞄触发方式::开火开镜) {
if (开镜判断 != 1) {
if (开火判断 != 1) {
IsAimLongAim = false;
{
    usleep(1000);
    usleep(randomNumber + 20);
    tx = xzb, ty = yzb;
    
    Touch_Up(6);
    isDown = false;
}
usleep(Config.自动瞄准.锁定强度 * 1000);
continue;
}
}
}
            float Acc = getScopeAcc((int)(90 / fov));

            if (isDown == false)
            {
                usleep(1000);
                usleep(randomNumber + 20);
                if (Config.自动瞄准.屏幕位置 == 0.0f)
                    Touch_Move(6, tx, ty);
                else
                    Touch_Move(6, screen_y - tx, screen_x - ty);
                isDown = true;
                usleep(1000);
            }

            if (zm_x > ScrXH)
            {
                TargetX = -(ScrXH - zm_x) / Config.自动瞄准.瞄准速度 * Acc;
                if (TargetX + ScrXH > ScrXH * 2)
                {
                    TargetX = 0;
                }
            }
            else if (zm_x < ScrXH)
            {
                TargetX = (zm_x - ScrXH) / Config.自动瞄准.瞄准速度 * Acc;
                if (TargetX + ScrXH < 0)
                {
                    TargetX = 0;
                }
            }

            if (zm_y > ScrYH)
            {
                TargetY = -(ScrYH - zm_y) / Config.自动瞄准.瞄准速度 * Acc;
                if (TargetY + ScrYH > ScrYH * 2)
                {
                    TargetY = 0;
                }
            }
            else if (zm_y < ScrYH)
            {
                TargetY = (zm_y - ScrYH) / Config.自动瞄准.瞄准速度 * Acc;
                if (TargetY + ScrYH < 0)
                {
                    TargetY = 0;
                }
            }

            if (TargetY >= 35 || TargetX >= 35 || TargetY <= -35 || TargetX <= -35)
            {
                usleep(1000);
                usleep(randomNumber + 16.5);
                tx = xzb, ty = yzb;
                
                Touch_Up(6);
                isDown = false;
                usleep(Config.自动瞄准.锁定强度 * 1000);
                continue;
            }

            tx += TargetX;
            ty += TargetY;

            if (tx >= xzb + Config.自动瞄准.触摸范围 || tx <= xzb - Config.自动瞄准.触摸范围 || ty >= yzb + Config.自动瞄准.触摸范围 || ty <= yzb - Config.自动瞄准.触摸范围)
            {

                
                Touch_Up(6);
                
                tx = xzb, ty = yzb;
                

                usleep(randomNumber + 20);
                
                if (!Config.自动瞄准.屏幕位置)
                    Touch_Move(6, tx, ty);
                else
                    Touch_Move(6, screen_y - tx, screen_x - ty);
                
                isDown = true;

                tx += TargetX;
                ty += TargetY;

                usleep(1000);
            }

            if (!Config.自动瞄准.屏幕位置)
                Touch_Move(6, tx, ty);
            else
                Touch_Move(6, screen_y - tx, screen_x - ty);

            isDown = true;

            usleep(Config.自动瞄准.锁定强度 * 1000);
            usleep(randomNumber + 20);
        }
        else
        {

            if (isDown)
            {
                tx = xzb, ty = yzb;
                
                Touch_Up(6);
                
                isDown = false;
                
                usleep(Config.自动瞄准.锁定强度 * 1000);
            }
        }
    }
}



                


int 数据() {
    DIR *dir = opendir("/dev/input/");
    if (dir == NULL) return -1;
    struct dirent *ptr = NULL;
    int count = 0;
    while ((ptr = readdir(dir)) != NULL) {
        if (strstr(ptr->d_name, "event"))
            count++;
    }
    closedir(dir);
    return count ? count : -1;
}

void 处理输入事件(struct input_event ev) {
    if (ev.type == EV_KEY && ev.value == 1) {
        if (ev.code == KEY_VOLUMEUP) { 
             IsBall = true;
             MemuSwitch = true;
            printf("\n");
        } else if (ev.code == KEY_VOLUMEDOWN) { 
             IsBall = false;
            printf("\n");
        }
    }
}

int 音量() {
    int EventCount = 数据();
    if (EventCount < 0) {
        printf("Input device not found\n");
        return -1;
    }

    int *fdArray = (int *)malloc(EventCount * sizeof(int));
    fd_set fds;
    struct timeval tv;
    int maxfd = 0;

    for (int i = 0; i < EventCount; i++) {
        char temp[128];
        sprintf(temp, "/dev/input/event%d", i);
        fdArray[i] = open(temp, O_RDONLY | O_NONBLOCK);
        if(fdArray[i] > maxfd) maxfd = fdArray[i];
    }

    struct input_event ev;

    while (1) {
        FD_ZERO(&fds);
        for (int i = 0; i < EventCount; i++) {
            FD_SET(fdArray[i], &fds);
        }

        tv.tv_sec = 5;
        tv.tv_usec = 0;

        int ret = select(maxfd + 1, &fds, NULL, NULL, &tv);
        if (ret == -1) {
            perror("select error");
            break;
        } else if (ret == 0) {
            continue;
        } else {
            for (int i = 0; i < EventCount; i++) {
                if (FD_ISSET(fdArray[i], &fds)) {
                    memset(&ev, 0, sizeof(ev));
                    if (read(fdArray[i], &ev, sizeof(ev)) == sizeof(ev)) {
                        处理输入事件(ev);
                    }
                }
                usleep(5000);
            }
            usleep(5000);
        }
        usleep(5000);
    }

    for (int i = 0; i < EventCount; i++) {
        if (fdArray[i] >= 0) close(fdArray[i]);
    }
    free(fdArray);

return 0;
}
   
int DrawInt() {

    
  
    NumIoLoad("Question Mod");
    进程 = 驱动->获取进程((char*)"com.tencent.ig");
    进程 = 驱动->获取进程((char*)"com.rekoo.pubgm");   
    进程 = 驱动->获取进程((char*)"com.vng.pubgmobile");
    进程 = 驱动->获取进程((char*)"com.pubg.krmobile");
    驱动->初始化(进程);
    memset(matrix, 0, 16);
	if (screen_x > screen_y) {
		py = screen_y/2;  
        px = screen_x/2;
	} else {
		py = screen_x/2;  
        px = screen_y/2;
	}
    基址头 = 驱动->获取基址头((char*)"libUE4.so");
    return 0;
}


void DrawPlayer(ImDrawList *draw) {


if(Config.自动瞄准.自瞄开关&&Config.自动瞄准.动态范围){

ImGui::GetForegroundDrawList()->AddCircle({px, py}, fwjl,ImColor(255,188,000,255),0,1.5f); 
} else {
ImGui::GetForegroundDrawList()->AddCircle({px, py}, Config.自动瞄准.自瞄范围,ImColor(255,188,000,255),0,1.5f); 
}


if (Config.自动瞄准.触摸位置) {
ImGui::GetForegroundDrawList()->AddRectFilled({0,0}, {px*2, py*2},ImColor(0,0,0,110));
std::string ssf;
ssf += "Don't let go of the control, press and drag";
ImGui::GetForegroundDrawList()->AddRectFilled({Config.自动瞄准.触摸位置Y - Config.自动瞄准.触摸范围/2, py*2 - Config.自动瞄准.触摸位置X + Config.自动瞄准.触摸范围/2}, {Config.自动瞄准.触摸位置Y + Config.自动瞄准.触摸范围/2, py*2 - Config.自动瞄准.触摸位置X - Config.自动瞄准.触摸范围/2},TouchingColor); 
ImGui::GetForegroundDrawList()->AddText(NULL,32,{Config.自动瞄准.触摸位置Y - 12,py*2 - Config.自动瞄准.触摸位置X + 12},ImColor(255,255,255),ssf.c_str());
}

if (Config.预警绘制.绘制雷达){
ImGui::GetForegroundDrawList()->AddRect({Config.预警绘制.雷达X轴 - Config.预警绘制.雷达大小,Config.预警绘制.雷达Y轴-Config.预警绘制.雷达大小},{Config.预警绘制.雷达X轴 +Config.预警绘制.雷达大小,Config.预警绘制.雷达Y轴+Config.预警绘制.雷达大小},ImColor(255,255,255,125),5,0,1.3f);

   }
    std::vector<uintptr_t> uworlds;

    std::vector<uintptr_t> uleves;

    std::vector<uintptr_t> arrayAddrs;

    std::vector<int> counts;


	
Gname = 驱动->读取指针(驱动->读取指针(基址头 + 0xe47e8f0) + 0x110);
long int 矩阵地址 = 驱动->读取指针(驱动->读取指针(基址头 + 0xEA4DC40) + 0x20) + 0x270;
long int 世界地址 = 驱动->读取指针(驱动->读取指针(驱动->读取指针(基址头 + 0xea79a90)+ 0x810) + 0x78); 
long int 对象列阵 = 驱动->读取指针(世界地址 + 0x30);
long int ActorArray = 驱动->读取指针(DecryptActorsArray(对象列阵, 0xa0, 0x488));
long int 对象数量 = 驱动->读取整数(对象列阵 + 0xA8);
自身结构体 = 驱动->读取指针(驱动->读取指针(驱动->读取指针(驱动->读取指针(世界地址 + 0x38)+ 0x78)+0x30) + 0x27a8); 
int 自身队伍 = 驱动->读取整数(自身结构体 + 0x938);


memset(matrix, 0, 16);
驱动->读取(矩阵地址, matrix, 16 * 4);

uworlds.push_back(世界地址);

uleves.push_back(对象列阵);

arrayAddrs.push_back(ActorArray);

counts.push_back(对象数量); 
玩家数量 = 0; 
人机数量 = 0;
狗子数量 = 0;
AimCount = 0;
AimCount1 = 0;
AimObjCount = 0;

for (int i = 0; i < 对象数量; i++) {
long int 对象结构体 = /*ActorArray[i]; */驱动->读取指针(ActorArray + 0x8 * i);


char* s_name = 获取类名(对象结构体);



Vector3A Z;
驱动->读取(驱动->读取指针(自身结构体 + 0x1B0) + 0x1C0, &Z, sizeof(Z));  
 
Vector3A D;
驱动->读取(驱动->读取指针(对象结构体 + 0x1B0) + 0x1C0, &D, sizeof(D)); 

Vector3A Movement;
驱动->读取(驱动->读取指针(对象结构体 + 0x1b0) + 0x260, &Movement, sizeof(Movement));

camera = matrix[3] * D.X + matrix[7] * D.Y + matrix[11] * D.Z + matrix[15];
double m = camera / 100;
r_x =
px + (matrix[0] * D.X + matrix[4] * D.Y + matrix[8] * D.Z +
matrix[12]) / camera * px;
r_y =
py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z - 5) +
matrix[13]) / camera * py;
r_w =
py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z + 205) +
matrix[13]) / camera * py;

float X = r_x - (r_y - r_w) / 4;
float Y = r_y;
float W = (r_y - r_w) / 2;

float MIDDLE = X + W / 2;
float BOTTOM = Y + W;
float TOP = Y - W;

float 距离 = m;
float Distance = m;

float left = (X + W / 2) - W / 2.6f;
float right = X + W / 1.12f;
                   if (W > 0)
{
    if (Config.人物绘制.绘制类名)
    {
        char info1[100];
        sprintf(info1, "%lx", 对象结构体);
        auto textSize2 = ImGui::CalcTextSize(info1, 0, 23);
        绘制加粗文本(23, MIDDLE - (textSize2.x / 2), Y, 黄色, 黑色, info1);
    } 
 }
if (驱动->读取浮点数(对象结构体 + 0x2a68) == 479.5f) {

long int 人物穿戴 = 驱动->读取指针(驱动->读取指针(驱动->读取指针(对象结构体 + 0x348) + 0x30) + 0x388);
int 人物穿戴甲 = 驱动->读取整数(人物穿戴 + 0x234);
int 人物穿戴包 = 驱动->读取整数(人物穿戴 + 0x1C4);
int 人物穿戴头 = 驱动->读取整数(人物穿戴 + 0x1FC);


getUTF8(PlayerName, 驱动->读取指针(对象结构体 + 0x900));

int 敌人阵营 = 驱动->读取整数(对象结构体 + 0x938);

int 人机判断;

                long int 人机 = 驱动->读取整数(对象结构体 + 0x9e9);
            if (人机==16842753 or 人机==16843009 or 人机==16843008) {
            人机判断 = 1;
            } else {
            人机判断 = 0;}

int 人物状态 = 驱动->读取整数(对象结构体 + 0xFa8);

float MinHealth = 驱动->读取浮点数(对象结构体 + 0xdb8);
float MaxHealth = 驱动->读取浮点数(对象结构体 + 0xdbc);



long int Bullet = (驱动->读取浮点数(对象结构体 + 0x1304) + 0x119c);

           if (人物状态 == 262144 || 人物状态 == 262152 || 人物状态 == 0)
            {
                continue;
            }
float angle = 驱动->读取浮点数(自身结构体 + 0x198)-90;
Vector2A Radar = rotateCoord(angle, (Z.X - D.X) / Config.预警绘制.缩放, (Z.Y -D.Y) / Config.预警绘制.缩放);

if(自身队伍 == 敌人阵营){
continue;
}


if(Config.人物绘制.忽略人机 && 人机判断 == 1){
continue;
}

if (人机判断==1){
	颜色1 = ImColor(152,251,152,185);
}else{
	颜色1 = ImColor(队伍颜色(敌人阵营));
}


if (敌人阵营 < 100){
头部 = 5;
胸部 = 4;
盆骨 = 0;
左肩膀 = 11;
右肩膀 = 32;
左手肘 = 12;
右手肘 = 33;
左手腕 = 63;
右手腕 = 62;
左大腿 = 52;
右大腿 = 56;
左膝盖 = 53;
右膝盖 = 57;
左脚腕 = 54;
右脚腕 = 58;
}




long int Mesh = 驱动->读取指针(对象结构体 + 0x4a8);

long int human = Mesh + 0x1B0;

long int Bone = 驱动->读取指针(Mesh + 0x8b8) + 0x30;



FTransform meshtrans = getBone(human);
FMatrix c2wMatrix = TransformToMatrix(meshtrans);


  FTransform headtrans = getBone(Bone + 头部 * 48);
  FMatrix boneMatrix = TransformToMatrix(headtrans);
  Vector3A relLocation = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
   Head = WorldToScreen(relLocation, matrix, camera);
  
  FTransform chesttrans = getBone(Bone + 胸部 * 48);
  FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
  Vector3A relLocation1 = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
   Chest = WorldToScreen(relLocation1, matrix, camera);
  
  FTransform pelvistrans = getBone(Bone + 盆骨 * 48);
  FMatrix boneMatrix2 = TransformToMatrix(pelvistrans);
  Vector3A LrelLocation1 = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
   pelvis = WorldToScreen(LrelLocation1, matrix, camera);
  
  FTransform lshtrans = getBone(Bone + 左肩膀 * 48);
  FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
  Vector3A relLocation2 = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
   Left_Shoulder = WorldToScreen(relLocation2, matrix, camera);
  
  FTransform rshtrans = getBone(Bone + 右肩膀 * 48);
  FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
  Vector3A relLocation3 = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
   Right_Shoulder = WorldToScreen(relLocation3, matrix, camera);
  
  FTransform lelbtrans = getBone(Bone + 左手肘 * 48);
  FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
  Vector3A relLocation4 = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
   Left_Elbow = WorldToScreen(relLocation4, matrix, camera);
  
  FTransform relbtrans = getBone(Bone + 右手肘 * 48);
  FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
  Vector3A relLocation5 = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
   Right_Elbow = WorldToScreen(relLocation5, matrix, camera);
  
  FTransform lwtrans = getBone(Bone + 左手腕 * 48);
  FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
  Vector3A relLocation6 = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
   Left_Wrist = WorldToScreen(relLocation6, matrix, camera);
  
  FTransform rwtrans = getBone(Bone + 右手腕 * 48);
  FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
  Vector3A relLocation7 = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
   Right_Wrist = WorldToScreen(relLocation7, matrix, camera);
  
  FTransform Llshtrans = getBone(Bone + 左大腿 * 48);
  FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
  Vector3A LrelLocation2 = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
   Left_Thigh = WorldToScreen(LrelLocation2, matrix, camera);
  
  FTransform Lrshtrans = getBone(Bone + 右大腿 * 48);
  FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
  Vector3A LrelLocation3 = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
   Right_Thigh = WorldToScreen(LrelLocation3, matrix, camera);
  
  FTransform Llelbtrans = getBone(Bone + 左膝盖 * 48);
  FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
  Vector3A LrelLocation4 = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
   Left_Knee = WorldToScreen(LrelLocation4, matrix, camera);
  
  FTransform Lrelbtrans = getBone(Bone + 右膝盖 * 48);
  FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
  Vector3A LrelLocation5 = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
   Right_Knee = WorldToScreen(LrelLocation5, matrix, camera);
  
  FTransform Llwtrans = getBone(Bone + 左脚腕 * 48);
  FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
  Vector3A LrelLocation6 = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
  Left_Ankle = WorldToScreen(LrelLocation6, matrix, camera);
  
  FTransform Lrwtrans = getBone(Bone + 右脚腕 * 48);
  FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
  Vector3A LrelLocation7 = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
  Right_Ankle = WorldToScreen(LrelLocation7, matrix, camera);


FTransform Maxs = getBone(Bone + 6 * 48);
FMatrix boneMatrix15 = TransformToMatrix(Maxs);
Vector3A Max = MarixToVector(MatrixMulti(boneMatrix15, c2wMatrix));

FTransform Mins = getBone(Bone + 58 * 48);
FMatrix boneMatrix16 = TransformToMatrix(Mins);
Vector3A Min = MarixToVector(MatrixMulti(boneMatrix16, c2wMatrix));

FTransform Rootz = getBone(Bone + 0 * 48);
FMatrix boneMatrix17 = TransformToMatrix(Rootz);
Vector3A relLocation99 = MarixToVector(MatrixMulti(boneMatrix17, c2wMatrix));
auto Roots = WorldToScreen(relLocation99, matrix, camera);


FTransform headtransA = getBone(Bone + 头部 * 48);
FMatrix boneMatrixA1 = TransformToMatrix(headtransA);
Vector3A relLocationA1 = MarixToVector(MatrixMulti(boneMatrixA1, c2wMatrix));
AimHead = WorldToScreen(relLocationA1, matrix, camera);

FTransform chesttransA = getBone(Bone + 胸部 * 48);
FMatrix boneMatrixA2 = TransformToMatrix(chesttransA);
Vector3A relLocationA2 = MarixToVector(MatrixMulti(boneMatrixA2, c2wMatrix));
AimChest = WorldToScreen(relLocationA2, matrix, camera);

FTransform pelvistransA = getBone(Bone + 盆骨 * 48);
FMatrix boneMatrixA3 = TransformToMatrix(pelvistransA);
Vector3A LrelLocationA3 = MarixToVector(MatrixMulti(boneMatrixA3, c2wMatrix));
Aimpelvis = WorldToScreen(LrelLocationA3, matrix, camera);


if (LrelLocation6.Z < LrelLocation7.Z) {
LrelLocation7.Z = LrelLocation6.Z;
}

float top1 = pelvis.Y - Head.Y;
float top = pelvis.Y - top1 - W / 5;

if (Left_Ankle.Y < Right_Ankle.Y) {
float bottom = Right_Ankle.Y + W / 10;
} else {
float bottom = Left_Ankle.Y+ W / 10;
}

if (W > 0){
if ((Config.自动瞄准.忽略倒地 == false || (Config.自动瞄准.忽略倒地 && MinHealth > 0)) && (Config.自动瞄准.忽略人机 == false || (Config.自动瞄准.忽略人机 && 人机判断 == 0))) {
Aim[AimCount].WodDistance = Distance;
Aim[AimCount].AimMovement = Movement;

Aim[AimCount].ObjAim = relLocationA2;
Aim[AimCount].ScreenDistance = sqrt(pow(px - AimHead.X, 2) + pow(py - AimHead.Y, 2));


if(Config.自动瞄准.自瞄开关){
if(findminat()==AimCount) {
ImGui::GetForegroundDrawList()->AddLine({px , py}, {Head.X, Head.Y}, ImColor(148,0,211), Config.自动瞄准.范围粗细);
}
}
AimCount++;
}
}




if (Config.预警绘制.绘制雷达) {
{     
    if (距离 <= 3)
    {                 
      
     std::string ld;
     if (Config.预警绘制.雷达X轴 + Radar.X >= Config.预警绘制.雷达X轴 - 100 && Config.预警绘制.雷达X轴+ Radar.X <= Config.预警绘制.雷达X轴 + 100 && Config.预警绘制.雷达Y轴 + Radar.Y >= Config.预警绘制.雷达Y轴- 100 && Config.预警绘制.雷达Y轴 + Radar.Y <= Config.预警绘制.雷达Y轴 + 100) {              
        if (人机判断 == 1) {
        ImGui::GetForegroundDrawList()->AddCircleFilled({Config.预警绘制.雷达X轴+ Radar.X, Config.预警绘制.雷达Y轴+ Radar.Y}, {20}, ImColor(255, 255, 255));        
        ld += "AI";
        auto textSize = ImGui::CalcTextSize(ld.c_str(), 0, 25);
        
        ImGui::GetForegroundDrawList()->AddText(NULL, 20.f, {Config.预警绘制.雷达X轴+ Radar.X-10, Config.预警绘制.雷达Y轴+ Radar.Y - 10}, ImColor(50, 50, 50), ld.c_str());                              
        } else {
        static float tm = 127/255.f;
        ImGui::GetForegroundDrawList()->AddCircleFilled({Config.预警绘制.雷达X轴+ Radar.X, Config.预警绘制.雷达Y轴+ Radar.Y}, {20}, ImColor(arr[敌人阵营 % length]));
        if (Config.预警绘制.雷达样式 == 0.0){
        ld += to_string((int)敌人阵营);
        }else if (Config.预警绘制.雷达样式 == 1.0){
        ld += to_string((int)距离);
        }if (Config.预警绘制.雷达样式 == 2.0){
        ld += to_string((int)MinHealth);
        }if (Config.预警绘制.雷达样式 == 3.0){
        ld +=PlayerName ;
        }
        auto textSize = ImGui::CalcTextSize(ld.c_str(), 0, 25);
        
        ImGui::GetForegroundDrawList()->AddText(NULL, 20.f, {Config.预警绘制.雷达X轴+ Radar.X-10, Config.预警绘制.雷达Y轴+ Radar.Y - 10}, ImColor(255, 255, 255), ld.c_str());   }
        }
      
    }
}}
if (Config.预警绘制.背敌预警) {
std::string ssd;
ssd += std::to_string((int) 距离);
ssd += "m";
auto textSize = ImGui::CalcTextSize(ssd.c_str(), nullptr, true);
if(人机判断 == 1){
if (X + W / 2 < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({0, Head.Y}, 60, ImColor(255, 255, 255, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {5, Head.Y - 20}, ImColor(000, 000, 000, 200),ssd.c_str());
} else if (W > 0 && X > px * 2) {
ImGui::GetForegroundDrawList()->AddCircleFilled({px * 2, Head.Y}, 60, ImColor(255, 255, 255, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {px * 2 - 50, Head.Y - 20},ImColor(000, 000, 000, 200),ssd.c_str());
} else if (W > 0 && Y + W < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({Head.X, 0}, 60, ImColor(255, 255, 255, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {Head.X - 30, 10}, ImColor(000, 000, 000, 200),ssd.c_str());
} else if (W < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({px * 2 - Head.X, py * 2}, 60, ImColor(255, 255, 255, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {px * 2 - Head.X - 30, py * 2 - 30},ImColor(000, 000, 000, 200), ssd.c_str());
}
}else{
if (X + W / 2 < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({0, Head.Y}, 60, ImColor(255, 000, 000, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {5, Head.Y - 20}, ImColor(255, 255, 255, 200),ssd.c_str());
} else if (W > 0 && X > px * 2) {
ImGui::GetForegroundDrawList()->AddCircleFilled({px * 2, Head.Y}, 60, ImColor(255, 000, 000, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {px * 2 - 50, Head.Y - 20},ImColor(255, 255, 255, 200),ssd.c_str());
} else if (W > 0 && Y + W < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({Head.X, 0}, 60, ImColor(255, 000, 000, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {Head.X - 30, 10}, ImColor(255, 255, 255, 200),ssd.c_str());
} else if (W < 0) {
ImGui::GetForegroundDrawList()->AddCircleFilled({px * 2 - Head.X, py * 2}, 60, ImColor(255, 000, 000, 125));
ImGui::GetForegroundDrawList()->AddText(nullptr, 35, {px * 2 - Head.X - 30, py * 2 - 30},ImColor(255, 255, 255, 200), ssd.c_str());
}
}
}







if(W > 0) {

if (Config.人物绘制.绘制方框) {
ImGui::GetForegroundDrawList()->AddRect({X, TOP}, {X + W, BOTTOM},颜色1, 0, 0, 1.3f);
}

if (Config.人物绘制.绘制射线) {

if (LINE == LINE::line1) {
ImGui::GetForegroundDrawList()->AddLine({px , 150.0f}, {Head.X, TOP - 50}, 颜色1, {1.5});
}
if (LINE == LINE::line2) {
ImGui::GetForegroundDrawList()->AddLine({px, py}, {Head.X, Head.Y}, 颜色1, {1.5});
}
if (LINE == LINE::line3) {
ImGui::GetForegroundDrawList()->AddLine({px, 1000}, {Head.X, Head.Y}, 颜色1, {1.5});
}
}

if (Config.人物绘制.绘制骨骼) {
               

if (人机判断 == 1) {
ImGui::GetForegroundDrawList()->AddCircle({Head.X , Head.Y}, W/11, ImColor(255, 255, 255, 255), 0);
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {pelvis.X, pelvis.Y},ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({pelvis.X, pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({pelvis.X, pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, ImColor(255, 255, 255, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, ImColor(255, 255, 255, 255),{2});  
}else{
ImGui::GetForegroundDrawList()->AddCircle({Head.X , Head.Y}, W/11, ImColor(255, 000, 000, 255), 0);
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {pelvis.X, pelvis.Y},ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({pelvis.X, pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({pelvis.X, pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, ImColor(255, 000, 000, 255),{2});
ImGui::GetForegroundDrawList()->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, ImColor(255, 000, 000, 255),{2});  
}

}

if (Config.人物绘制.绘制信息) {
绘制信息(MinHealth,MIDDLE,TOP,人机判断,敌人阵营);	
}



if (Config.人物绘制.绘制距离) {
std::string s;
s += std::to_string((int)距离);
s += "M";
auto textSize2 = ImGui::GetFont()->CalcTextSizeA(18, FLT_MAX, -1, s.c_str(), NULL, NULL);
绘制加粗文本(28,MIDDLE - (textSize2.x / 1    ),BOTTOM + 10,ImColor(255,255,255),黑色,s.c_str());
}
 char *名称;
}

if (W>0)
{
if (Config.其他绘制.头) 
{
std::string s; 
s += "[";
s += tou(人物穿戴头);
s += "|";
s += jia(人物穿戴甲);
s += "|";
s += bao(人物穿戴包);
s += "]";
auto textSize2 = ImGui::GetFont()->CalcTextSizeA(20, FLT_MAX, -1, s.c_str(), NULL, NULL);
绘制加粗文本(20,MIDDLE - (textSize2.x /2 ),BOTTOM + 30,白色,黑色,s.c_str());
}              
}

if (人机判断 == 1) {
人机数量++;
}else{
玩家数量++;
}
}

char *CasName;
         
if (W > 0){

if (Config.其他绘制.载具绘制) 
{ 
if(strstr(s_name, "BP_VH_Buggy_2_C") != nullptr  || strstr(s_name, "VH_4SportCar_C") != nullptr || strstr(s_name, "VH_UAZ01_New_C") != nullptr || strstr(s_name, "VH_Dacia_New_C") != nullptr  || strstr(s_name, "VH_Horse_1_C") != nullptr || strstr(s_name, "VH_CoupeRB_1_C") != nullptr || strstr(s_name, "VH_Motorcycle_1_C") != nullptr  || strstr(s_name, "VH_StationWagon_C") != nullptr || strstr(s_name, "BP_VH_Bigfoot_C") != nullptr || strstr(s_name, "VH_ATV1_C") != nullptr  || strstr(s_name, "BP_CoupeRB_Base_C") != nullptr || strstr(s_name, "Mirado_open_1_C") != nullptr || strstr(s_name, "PickUp_02_C") != nullptr  || strstr(s_name, "Rony_01_C") != nullptr || strstr(s_name, "BP_VH_Tuk_1_C") != nullptr || strstr(s_name, "VH_Snowbike_02_C") != nullptr  || strstr(s_name, "VH_Snowbike_C") != nullptr || strstr(s_name, "LadaNiva_01_C") != nullptr || strstr(s_name, "VH_Scooter_C") != nullptr  || strstr(s_name, "VH_MotorcycleCart_1_C") != nullptr || strstr(s_name, "VH_MiniBus_01_C") != nullptr || strstr(s_name, "VH_PG117_C") != nullptr  || strstr(s_name, "AquaRail_1_C") != nullptr || strstr(s_name, "VH_BRDM_C") != nullptr || strstr(s_name, "") != nullptr || strstr(s_name, "VH_Motorglider_C") != nullptr || strstr(s_name, "VH_Mountainbike_Training_C") != nullptr  ) {
std::string ss;
        if(strstr(s_name, "BP_VH_Buggy_2_C") != nullptr  ) {
        ss += "Buggy\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_4SportCar_C") != nullptr  ) {
        ss += "Sports Car\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "VH_UAZ01_C") != nullptr  ) {
        ss += "Jeep\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
    if(strstr(s_name, "VH_Dacia_C") != nullptr  ) {
        ss += "Sedan\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_Horse_1_C") != nullptr  ) {
        ss += "Horse\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "VH_CoupeRB_1_C") != nullptr  ) {
        ss += "Coupe\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
     if(strstr(s_name, "VH_Motorcycle_1_C") != nullptr  ) {
        ss += "Motorcycle\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_StationWagon_C") != nullptr  ) {
        ss += "Station Wagon\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "BP_VH_Bigfoot_C") != nullptr  ) {
        ss += "Bigfoot\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
    if(strstr(s_name, "VH_ATV1_C") != nullptr  ) {
        ss += "ATV\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "BP_CoupeRB_Base_C") != nullptr  ) {
        ss += "Sports Coupe\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "Mirado_open_4_C") != nullptr  ) {
        ss += "Muscle Car\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
 if(strstr(s_name, "PickUp_07_C") != nullptr  ) {
        ss += "Pickup Truck\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "Rony_01_C") != nullptr  ) {
        ss += "Rony Truck\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "BP_VH_Tuk_1_C") != nullptr  ) {
        ss += "Tuk Tuk\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
    if(strstr(s_name, "VH_Snowbike_02_C") != nullptr  ) {
        ss += "Snow Bike\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_Snowbike_C") != nullptr  ) {
        ss += "Heavy Snow Bike\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "LadaNiva_01_C") != nullptr  ) {
        ss += "Offroad Vehicle\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
     if(strstr(s_name, "VH_Scooter_C") != nullptr  ) {
        ss += "Scooter\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_MotorcycleCart_1_C") != nullptr  ) {
        ss += "Motorcycle Cart\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
    if(strstr(s_name, "VH_MiniBus_01_C") != nullptr  ) {
        ss += "Minibus\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
    if(strstr(s_name, "VH_PG117_C") != nullptr  ) {
        ss += "Boat\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
        if(strstr(s_name, "AquaRail_1_C") != nullptr  ) {
        ss += "Jet Ski\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "VH_BRDM_C") != nullptr  ) {
        ss += "Armored Vehicle\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    } 
    
     if(strstr(s_name, "VH_UTV_C") != nullptr  ) {
        ss += "UTV\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
     if(strstr(s_name, "VH_Motorglider_C") != nullptr  ) {
        ss += "Glider\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
    if(strstr(s_name, "VH_Mountainbike_Training_C") != nullptr  ) {
        ss += "Bicycle\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 蓝色, 黑色, ss.c_str());   
    }
    
  }  
    
}


if (Config.其他绘制.手雷绘制) {
ImColor 投掷物颜色 = 红色;
if (fmodf((float)ImGui::GetTime(), 0.40f) < 0.20f)
{
    投掷物颜色 = 红色;
}
if(strstr(s_name, "BP_Grenade_Burn_C") != nullptr ||strstr(s_name, "EProjStun_BP_C") != nullptr ||strstr(s_name, "BP_Grenade_Smoke_C") != nullptr ||strstr(s_name, "BP_Grenade_Shoulei_C") != nullptr || strstr(s_name, "ProjBurn_BP_C") != nullptr ||strstr(s_name, "ProjStun_BP_C") != nullptr ||strstr(s_name, "ProjSmoke_BP_C") != nullptr ||strstr(s_name, "ProjGrenade_BP_C") != nullptr  ) {
    std::string ss;
    if(strstr(s_name, "BP_Grenade_Burn_C") != nullptr) {
        ss += "Molotov";
    }
    
    if(strstr(s_name, "EProjStun_BP_C") != nullptr) {
        ss += "Stun Grenade";
    }
    
    if (strstr(s_name, "BP_Grenade_Smoke_C") != nullptr) {
        ss += "Smoke Grenade";
    }
    
    if(strstr(s_name, "BP_Grenade_Shoulei_C") != nullptr) {
        ss += "Grenade";
    }
    
    if(strstr(s_name, "ProjBurn_BP_C") != nullptr) {
        ss += "Molotov";
    }    
    
    if(strstr(s_name, "ProjStun_BP_C") != nullptr) {
        ss += "Stun Grenade";
    }
    
    if (strstr(s_name, "ProjSmoke_BP_C") != nullptr) {
        ss += "Smoke Grenade";
    }
    
    if(strstr(s_name, "ProjGrenade_BP_C") != nullptr) {
        ss += "Grenade";
    }
    
    ss += to_string((int)m);
    ss += "m";
    
    auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 红色, 黑色, ss.c_str());
ImGui::GetForegroundDrawList()->AddCircleFilled({MIDDLE , Y}, W/13, ImColor(255, 0, 0, 255), 0);
std::string str2 = "Grenade Nearby!!!";  
ImGui::GetForegroundDrawList()->AddText(NULL, 35, ImVec2(px - 120.0f, 160.0f), 投掷物颜色, str2.c_str()); 	
}
}

if (Config.其他绘制.箱子绘制) 
{
if(strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv1_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv1_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv2_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv2_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv2_2_C")!= nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv3_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv3_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv4_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv4_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv4_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv1_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv2_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv2_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv3_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv4_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv4_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv1_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv2_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv2_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv3_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv4_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv4_2_C")!= nullptr ) {
    std::string ss;
    if(strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv1_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv1_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv2_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv2_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv2_2_C")!= nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv3_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv3_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv4_C")  != nullptr || strstr(s_name, "BP_DC_HighLevel_TE_WeaponBox_Lua_Lv4_2_C ")  != nullptr   ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_WeaponBox_Lua_Lv4_2_C")!= nullptr ) {
        ss += "Weapon Box\n";
        ss += to_string((int)m);
        ss += "m";
    }
    
    if(strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv1_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv2_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv2_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv3_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_ItemBox_Lua_Lv4_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_ItemBox_Lua_Lv4_2_C")!= nullptr){
        ss += "Supply Box\n";
        ss += to_string((int)m);
        ss += "m";
    }
    
    if(strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv1_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv1_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv1_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv2_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv2_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv2_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv3_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv3_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv3_2_C")!= nullptr || strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_HighLevel_TE_FileBox_Lua_Lv4_2_C ") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv4_C") != nullptr ||strstr(s_name, "BP_DC_TE_FileBox_Lua_Lv4_2_C")!= nullptr) {
        ss += "File Box\n";
        ss += to_string((int)m);
        ss += "m";
    }
    
    if(驱动->读取整数(对象结构体 + 0x1A0) == 0) {
        ss += "(Closed)";
    }else{ 
        ss += "(Opened)";
    }  
   auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 绿色, 黑色, ss.c_str());  
}

}

if (Config.其他绘制.盒子绘制) 
{ 
if(strstr(s_name, "XTPlayerDeadInventoryBox_C") != nullptr  || strstr(s_name, "EscapePlayerTombBox_C") != nullptr ) {
std::string ss;
        if(strstr(s_name, "XTPlayerDeadInventoryBox_C") != nullptr  ) {
        ss += "Loot Box - ";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 黄色, 黑色, ss.c_str());   
    }
    
   if(strstr(s_name, "BP_Escape_MonsterDeadInventoryBox_C") != nullptr  ) {
        ss += "Loot Box\n";
        ss += to_string((int)m);
        ss += "m";
        auto textSize2 = ImGui::GetFont()->CalcTextSizeA(23, FLT_MAX, -1, ss.c_str(), NULL, NULL);
    绘制加粗文本(23, MIDDLE - (textSize2.x/2), Y, 黄色, 黑色, ss.c_str());   
     } 
    }    
   }
  }





 uworlds.clear();

 uleves.clear();

 arrayAddrs.clear();

 counts.clear();

}
		
		








					



MaxPlayerCount = AimCount;
int AllCount{人机数量 + 玩家数量}; 


ImColor textColor;  
if (玩家数量 > 0 && 人机数量 > 0) {  
    textColor = ImColor(255,0,0,255); 
} else if (玩家数量 > 0) {  
    textColor = ImColor(255,0,0,255); 
} else if (人机数量 > 0) {  
    textColor = ImColor(255,188,000,255); 
} else {  
    textColor = ImColor(255, 255, 255, 255); 
}


if (AllCount > 0) {
    
    std::string playerText = "Player: " + std::to_string(AllCount);
    
    
    auto textSize = ImGui::CalcTextSize(playerText.c_str());
    
    
    float padding = 35.0f;
    float bgWidth = textSize.x + padding * 4;
    float bgHeight = textSize.y + padding;
    
    
    float bgX = px - bgWidth / 2;
    float bgY = 90.0f + 20; 
    
    
    ImGui::GetForegroundDrawList()->AddRectFilled(
        {bgX, bgY}, 
        {bgX + bgWidth, bgY + bgHeight}, 
        ImColor(0, 0, 0, 150), 
        10.0f 
    );
    
    
    ImGui::GetForegroundDrawList()->AddText(
        NULL, 
        35, 
        {bgX + padding, bgY + padding / 2}, 
        textColor, 
        playerText.c_str()
    );
   
} else {
    
    std::string str2 = "? MOD";  
    ImGui::GetForegroundDrawList()->AddText(
        NULL, 
        50, 
        ImVec2(px - 50.5f, 90.0f + 20), 
        ImColor(textColor), 
        str2.c_str()
    );
}



}

void DrawLogo(ImVec2 center, float size) {
ImGui::SetCursorPos({0, 180});
ImGui::SetCursorPos({0, 180});
ImDrawList *draw_list = ImGui::GetWindowDrawList();
draw_list->AddImage(FloatBall,{center.x - size /1,center.y - size / 1},{center.x + size / 1,center.y + size / 1});
}

bool Tabb,interface3,isDown,isTe;

void tick() {
    ImGuiIO& io = ImGui::GetIO();
    static ImVec4 clear_color = ImVec4(0, 0, 0, 0);

ImGuiStyle &style = ImGui::GetStyle();


style.Colors[ImGuiCol_Text] = ImColor(255, 255, 255); 
style.Colors[ImGuiCol_WindowBg] = ImColor(0, 0, 0); 
style.Colors[ImGuiCol_Button] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_ButtonHovered] = ImColor(200, 0, 0); 
style.Colors[ImGuiCol_ButtonActive] = ImColor(150, 0, 0); 
style.Colors[ImGuiCol_FrameBg] = ImColor(40, 40, 40); 
style.Colors[ImGuiCol_FrameBgActive] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_FrameBgHovered] = ImColor(60, 60, 60); 
style.Colors[ImGuiCol_CheckMark] = ImColor(255, 255, 255); 
style.Colors[ImGuiCol_SliderGrab] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_SliderGrabActive] = ImColor(200, 0, 0); 
style.Colors[ImGuiCol_Header] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_HeaderHovered] = ImColor(200, 0, 0); 
style.Colors[ImGuiCol_HeaderActive] = ImColor(150, 0, 0); 
style.Colors[ImGuiCol_ScrollbarBg] = ImColor(20, 20, 20); 
style.Colors[ImGuiCol_ScrollbarGrab] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImColor(200, 0, 0); 
style.Colors[ImGuiCol_ScrollbarGrabActive] = ImColor(150, 0, 0); 
style.Colors[ImGuiCol_Separator] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_Border] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_BorderShadow] = ImColor(0, 0, 0); 


style.Colors[ImGuiCol_TitleBg] = ImColor(255, 0, 0); 
style.Colors[ImGuiCol_TitleBgActive] = ImColor(200, 0, 0); 
style.Colors[ImGuiCol_TitleBgCollapsed] = ImColor(100, 0, 0); 
style.Colors[ImGuiCol_MenuBarBg] = ImColor(20, 20, 20); 


style.GrabRounding = 5.0f;
style.GrabMinSize = 35.0f;

style.FrameRounding = 5.0f;
style.FrameBorderSize = 0.5f;
style.FramePadding = ImVec2(5, 8); 

style.ScrollbarSize = 35.0f;
style.ScrollbarRounding = 5.0f;

style.WindowBorderSize = 1.0f; 
style.WindowTitleAlign = ImVec2(0.5, 0.5);
style.WindowRounding = 8.0f; 


style.ChildRounding = 5.0f;
style.PopupRounding = 5.0f;
style.TabRounding = 5.0f;

static float ANIM_SPEED = 0.25f;
static float Velua = IsBall ? 0.0f : 1.0f;
Velua = ImClamp(Velua + (io.DeltaTime / ANIM_SPEED) * (IsBall ? 1.0f : -1.0f), 0.0f, 1.0f);

float windowWidth = 1000 * Velua;
float windowHeight = 550 * Velua;

float startPosX = screen_x / 2 - windowWidth / 2;
float startPosY = screen_y / 2 - windowHeight / 2;

if (screenshotScheduled) {
    double elapsed = ImGui::GetTime() - screenshotStartTime;
    if (elapsed >= 5.0) {
        takeScreenshot();
        tooltipStartTime = ImGui::GetTime();
        screenshotScheduled = false;
    }
}

if (showOverlay) {
    ImGuiViewport* viewport = ImGui::GetMainViewport();
    ImVec2 center = viewport->GetCenter();
    ImVec2 overlay_pos = ImVec2(center.x - 100, center.y - 50); 

    ImGui::SetNextWindowPos(overlay_pos, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.6f); 

    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_AlwaysAutoResize |
        ImGuiWindowFlags_NoInputs |
        ImGuiWindowFlags_NoNav;

    ImGui::Begin("ScreenshotOverlay", nullptr, flags);

    if (screenshotScheduled) {
        float remaining = 5.0f - (ImGui::GetTime() - screenshotStartTime);
        ImGui::Text("!!!Screenshot in %.1f...", remaining);
    } else if ((ImGui::GetTime() - tooltipStartTime) < 2.0) {
        ImGui::Text("Screenshot taken!");
    } else {
        showOverlay = false; 
    }
    ImGui::End();
}

if (IsBall) {
    
    ImGui::SetWindowSize("##QUESTION MOD", {windowWidth, windowHeight});
    ImGui::SetWindowPos("##QUESTION MOD", {startPosX, startPosY});
} else {
    
    float targetPosX = screen_x / 2 - windowWidth / 2;
    float targetPosY = screen_y / 2 - windowHeight / 2;

    ImGui::SetWindowSize("##QUESTION MOD", {windowWidth, windowHeight});
    ImGui::SetWindowPos("##QUESTION MOD", {ImLerp(startPosX, targetPosX, Velua), ImLerp(startPosY, targetPosY, Velua)});
}

if (windowWidth <= 100 && !IsBall) {
    BallSwitch = true;
    MemuSwitch = false;
}

if (MemuSwitch) {
style.WindowRounding = 10.0f;
if (ImGui::Begin("##QUESTION MOD", &MemuSwitch, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar)) {


auto Pos = ImGui::GetWindowPos();
Window = ImGui::GetCurrentWindow();
ImDrawList *draw_list = ImGui::GetWindowDrawList();
ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
if (ImGui::BeginChild("##MainMenu", ImVec2(150, -1), false, ImGuiWindowFlags_NoScrollbar)) {
auto Pos = ImGui::GetWindowPos();
DrawLogo({Pos.x + 83, Pos.y + 93}, 80);
ImGui::SetCursorPos({0, 180});

if (ImGui::Button("Home", ImVec2(150, 50))) {
MenuTab = 1;
}
if (ImGui::Button("Visuals", ImVec2(150, 50))) {
MenuTab = 2;
}
if (ImGui::Button("Aim", ImVec2(150, 50))) {
MenuTab = 3;
}
if (ImGui::Button("Settings", ImVec2(150, 50))) {
MenuTab = 4;
}
if (ImGui::Button("Minimize", ImVec2(150, 50))) {
IsBall = false;
}
}
ImGui::EndChild();
ImGui::PopStyleVar(1);
ImGui::SameLine();
ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
ImGui::SameLine();
ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
ImGui::SameLine();
if (ImGui::BeginChild("##RightMenu", ImVec2(-1, -1), false)) {
ImGui::Spacing();
ImGui::Spacing();
ImGui::TextColored(ImColor(255,0,00), "Question Mod V1 - Pubg Version 4.0 - 64 BIT");
ImGui::Separator();
switch (MenuTab) {
case 1: {
ImGuiLayout1();
}
break;
case 2: {
ImGuiLayout2();
}
break;
case 3: {
ImGuiLayout3();
}
break;
case 4: {
ImGuiLayout4();
}
break;
}
}
ImGui::EndChild();
ImGui::PopStyleVar(1);
}
ImGui::End();
}

if (IsWin) {
IsWin = false;
IsLoGin = false;
BallSwitch = false;
ImGui::SetWindowSize("Ball", {120.0f, 150.0f});
}
DrawPlayer(ImGui::GetForegroundDrawList());
ImGui::End();
ImGui::Render();
FPS = 帧数;

}

void ImGuiLayout1() {

if (链接驱动) {
ImGui::Button("Reload", {-1,70});
} else {
if (ImGui::Button("Load Game",{-1,70})) {

NumIoLoad("QuestionConfig");
DrawInt();
}
}

if (ImGui::Button("Exit Program",{-1,70})) {

NumIoSave("QuestionConfig");
exit(0);
}
if (ImGui::Button("Screenshot", ImVec2(-1, 70))) {
        screenshotScheduled = true;
        screenshotStartTime = ImGui::GetTime();
        showOverlay = true;
    }
ImGui::Separator();
/*        */


ImGui::SliderInt("##FPS Adjustment", &帧数, 60, 144);
ImGui::Text("Device Resolution: %dx%d", screen_x,screen_y);
ImGui::Text("Appname: %d", 进程); 
ImGui::Text("libUE4.so: 0x%lX", 基址头);

ImGui::EndChild();
}


void ImGuiLayout2() {

        if (ImGui::Button("One-Click Visuals", {-1, 65}))
        {
            Config.人物绘制.绘制方框 = true;
            Config.人物绘制.绘制射线 = true;
            Config.人物绘制.绘制骨骼 = true;
            Config.人物绘制.绘制信息 = true;
            Config.人物绘制.绘制血量 = true;
            Config.人物绘制.绘制距离 = true;
            Config.其他绘制.头       = true;
            Config.预警绘制.绘制雷达 = true;
            Config.其他绘制.手持武器 = true;
            Config.其他绘制.盒子绘制 = true;
            Config.其他绘制.箱子绘制 = true;
            Config.其他绘制.载具绘制 = true;
            Config.其他绘制.手雷绘制 = true;
            Config.预警绘制.背敌预警 = true;
          /*  Config.自动瞄准.自瞄开关 = true;
            Config.自动瞄准.忽略倒地 = true;
            Config.自动瞄准.忽略人机 = true;*/
        }
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Spacing();
        ImGui::Checkbox("Player Box", &Config.人物绘制.绘制方框);
        ImGui::SameLine();
        ImGui::Checkbox("Player Line", &Config.人物绘制.绘制射线);
        ImGui::SameLine();
        ImGui::Checkbox("Player Skeleton", &Config.人物绘制.绘制骨骼);


        ImGui::Checkbox("Player Name", &Config.人物绘制.绘制信息);
        ImGui::SameLine();
        ImGui::Checkbox("Player Distance", &Config.人物绘制.绘制距离);
        ImGui::SameLine();
        ImGui::Checkbox("Player Head/Armor", &Config.其他绘制.头);
       
       
        ImGui::Checkbox("Draw Radar", &Config.预警绘制.绘制雷达);
        ImGui::SameLine();    
        ImGui::Checkbox("Held Weapon", &Config.其他绘制.手持武器);
        ImGui::SameLine();        
        ImGui::Checkbox("Box Draw", &Config.其他绘制.盒子绘制);
                        
        
        ImGui::Checkbox("Crate Draw", &Config.其他绘制.箱子绘制);
        ImGui::SameLine();   
        ImGui::Checkbox("Vehicle Draw", &Config.其他绘制.载具绘制);           
        ImGui::SameLine();
        ImGui::Checkbox("Grenade Draw", &Config.其他绘制.手雷绘制);
      
        ImGui::Checkbox("Enemy Behind Warning", &Config.预警绘制.背敌预警);        
        
        
ImGui::EndChild();
}
void ImGuiLayout3() {

ImGui::Checkbox("Aim", &Config.自动瞄准.自瞄开关);


ImGui::SameLine();
ImGui::Checkbox("Touch Position", &Config.自动瞄准.触摸位置);
if (ImGui::SliderFloat("Aim Range", &Config.自动瞄准.自瞄范围, 00.0f, 600.0f, "%0.1f"));



ImGui::Checkbox("Ignore Downed", &Config.自动瞄准.忽略倒地);
                 

ImGui::RadioButton("Touch Right Screen", &Config.自动瞄准.屏幕位置, 0.0f);      
ImGui::SameLine();
ImGui::RadioButton("Touch Left Screen", &Config.自动瞄准.屏幕位置, 1.0f);

if (ImGui::CollapsingHeader("Basic Settings")) {
if (ImGui::SliderFloat("Touch Size", &Config.自动瞄准.触摸范围, 0.0f, 600.0f, "%0.2f"));
if (ImGui::SliderFloat("Aim Speed", &Config.自动瞄准.瞄准速度, 0.00f, 50.00f, "%0.1f"));
if (ImGui::SliderFloat("Recoil Control", &Config.自动瞄准.压枪参数, 0.00f, 4.00f, "%0.1f"));
if (ImGui::SliderFloat("Aim Line Prediction", &Config.自动瞄准.预判参数, 0.1f, 2.0f, "%.1f", 5));
}


ImGui::EndChild();
}
void ImGuiLayout4() {

if (ImGui::Button("Reset Config",{-1,70})) {
ImGuiMenustyle();
system("rm -rf /data/QuestionConfig.txt");
}
ImGui::BulletText("Radar Display Method");
ImGui::RadioButton("Team", &Config.预警绘制.雷达样式, 0.0f);      
ImGui::SameLine();
ImGui::RadioButton("Distance", &Config.预警绘制.雷达样式, 1.0f);
ImGui::SameLine();
ImGui::RadioButton("Health", &Config.预警绘制.雷达样式, 2.0f);
ImGui::SameLine();
ImGui::RadioButton("Name", &Config.预警绘制.雷达样式, 3.0f);
if (ImGui::SliderFloat("Radar X Axis Adjustment", &Config.预警绘制.雷达X轴, 10.0f, 1400.0f, "%0.1f"))
{
}
if (ImGui::SliderFloat("Radar Y Axis Adjustment", &Config.预警绘制.雷达Y轴, 10.0f, 1400.0f, "%0.1f"))
{
}             


ImGui::EndChild();
}
