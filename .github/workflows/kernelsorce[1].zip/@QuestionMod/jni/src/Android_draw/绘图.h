void 绘制信息(float MinHealth,float MIDDLE,float TOP,int 人机判断,int 敌人阵营)
{
int CurHP = (int) std::max(0, std::min((int)MinHealth,100));
char *名字12;
if (人机判断==256){
名字12 = "RaBot";
}else{
名字12 = PlayerName;
}
char 名字_str[256];
sprintf(名字_str,"%d.%s", 敌人阵营,名字12);

ImVec2 textSize = ImGui::GetFont()->CalcTextSizeA(25, FLT_MAX, -1, 名字_str, NULL, NULL);
ImGui::GetForegroundDrawList()->AddRectFilled({MIDDLE - 95 + 10 - 5, TOP - 50}, {MIDDLE - 95 + (CurHP * 150 / 93) - 20 + 20 - 5, TOP - 25}, 颜色1, 6, 0);
ImGui::GetForegroundDrawList()->AddRect({MIDDLE - 95 + 10 - 5, TOP - 50}, {MIDDLE - 95 + (100 * 150 / 93) - 20 + 20 - 5, TOP - 25}, ImColor(0,0,0,255) ,6,0,1.3f);
ImGui::GetForegroundDrawList()->AddText(NULL, 25, {MIDDLE - 35 - (textSize.x / 2), TOP - 50}, ImColor(0, 0, 0, 255),名字_str);
}





